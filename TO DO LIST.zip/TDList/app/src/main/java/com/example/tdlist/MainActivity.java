package com.example.tdlist;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listViewTasks;
    private Button buttonAddTask;
    private TaskDatabase db;
    private List<Task> taskList;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewTasks = findViewById(R.id.listViewTasks);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        db = TaskDatabase.getDatabase(this);

        // Click listener for the "Add New Task" button
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
                startActivityForResult(intent, 1);
            }
        });

        // Initialize the GestureDetector
        gestureDetector = new GestureDetector(this, new GestureListener());

        // Set the OnTouchListener to handle all gestures
        listViewTasks.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });

        loadTasks();
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            int position = listViewTasks.pointToPosition((int) e.getX(), (int) e.getY());
            if (position != AdapterView.INVALID_POSITION) {
                Task selectedTask = taskList.get(position);
                // Open edit activity on single click
                Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
                intent.putExtra("TASK_ID", selectedTask.getId());
                intent.putExtra("TASK_TITLE", selectedTask.getTitle());
                intent.putExtra("TASK_DESCRIPTION", selectedTask.getDescription());
                intent.putExtra("IS_COMPLETED", selectedTask.isCompleted());
                startActivityForResult(intent, 1);
                return true;
            }
            return false;
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
            int position = listViewTasks.pointToPosition((int) e.getX(), (int) e.getY());
            if (position != AdapterView.INVALID_POSITION) {
                Task selectedTask = taskList.get(position);
                // Toggle completion status on double click
                selectedTask.setCompleted(!selectedTask.isCompleted());
                new UpdateTaskStatusAsync().execute(selectedTask);
                return true;
            }
            return false;
        }

        @Override
        public void onLongPress(MotionEvent e) {
            int position = listViewTasks.pointToPosition((int) e.getX(), (int) e.getY());
            if (position != AdapterView.INVALID_POSITION) {
                final Task taskToDelete = taskList.get(position);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Task")
                        .setMessage("Are you sure you want to delete this task?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                new DeleteTaskAsync().execute(taskToDelete);
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        }
    }

    private void loadTasks() {
        new LoadTasksAsync().execute();
    }

    private void updateListView() {
        if (taskList != null) {
            ArrayAdapter<Task> customAdapter = new ArrayAdapter<Task>(
                    MainActivity.this, android.R.layout.simple_list_item_1, taskList) {
                @NonNull
                @Override
                public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView textView = (TextView) view;
                    Task task = taskList.get(position);
                    textView.setText(task.getTitle());

                    if (task.isCompleted()) {
                        textView.setPaintFlags(textView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                        textView.setTextColor(Color.GRAY);
                    } else {
                        textView.setPaintFlags(textView.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                        textView.setTextColor(Color.BLACK);
                    }
                    return view;
                }
            };
            listViewTasks.setAdapter(customAdapter);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadTasks();
        }
    }

    private class LoadTasksAsync extends AsyncTask<Void, Void, List<Task>> {
        @Override
        protected List<Task> doInBackground(Void... voids) {
            return db.taskDao().getAllTasks();
        }

        @Override
        protected void onPostExecute(List<Task> tasks) {
            super.onPostExecute(tasks);
            taskList = tasks;
            updateListView();
        }
    }

    private class DeleteTaskAsync extends AsyncTask<Task, Void, Void> {
        @Override
        protected Void doInBackground(Task... tasks) {
            db.taskDao().delete(tasks[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(MainActivity.this, "Task deleted!", Toast.LENGTH_SHORT).show();
            loadTasks();
        }
    }

    private class UpdateTaskStatusAsync extends AsyncTask<Task, Void, Void> {
        @Override
        protected Void doInBackground(Task... tasks) {
            db.taskDao().update(tasks[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(MainActivity.this, "Task status updated!", Toast.LENGTH_SHORT).show();
            loadTasks();
        }
    }
}