// Define the package for your app.
package com.example.quotes;

// Import necessary Android and Java classes
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    // Declare the UI elements (Views)
    private TextView quoteTextView;
    private TextView authorTextView;
    private Button shareButton;

    // Use ArrayList to store quotes so we can shuffle them
    private ArrayList<String> allQuotes = new ArrayList<>();
    // Keep track of the current quote index
    private int currentQuoteIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the UI elements by their IDs
        quoteTextView = findViewById(R.id.quote_textview);
        authorTextView = findViewById(R.id.author_textview);
        shareButton = findViewById(R.id.share_button);

        // Load all the quotes from the text file in the assets folder
        loadQuotesFromAssets();

        // Display the first quote
        displayNextQuote();

        // Set up the click listener for the share button
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareQuote();
            }
        });

        // Add a click listener to the quoteTextView itself to change the quote
        quoteTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNextQuote();
            }
        });
    }

    /**
     * This method loads quotes from the 'quotes.txt' file in the assets folder.
     * It reads each line, splits it into quote and author, and adds it to the list.
     * After loading, it shuffles the list to ensure random, non-repeating order.
     */
    private void loadQuotesFromAssets() {
        try {
            // Open the quotes.txt file from the assets folder
            InputStream inputStream = getAssets().open("quotes.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;

            // Read each line until the end of the file
            while ((line = reader.readLine()) != null) {
                // Add the quote line to our list
                allQuotes.add(line);
            }

            reader.close();

            // Shuffle the list of quotes to get a random order
            Collections.shuffle(allQuotes);

        } catch (IOException e) {
            e.printStackTrace();
            // Handle the error if the file cannot be read
            quoteTextView.setText("Error loading quotes.");
            authorTextView.setText("");
        }
    }

    /**
     * Displays the next quote in the shuffled list.
     * It cycles back to the beginning once all quotes have been shown.
     */
    private void displayNextQuote() {
        if (!allQuotes.isEmpty()) {
            // Get the full quote string from the list
            String fullQuote = allQuotes.get(currentQuoteIndex);

            // Split the string into quote and author using the '|' separator
            String[] parts = fullQuote.split("\\|");

            String quote = parts[0];
            String author = (parts.length > 1) ? parts[1] : "Unknown";

            // Set the text for the TextViews
            quoteTextView.setText(quote);
            authorTextView.setText("- " + author);

            // Move to the next quote in the list
            currentQuoteIndex++;

            // If we've reached the end of the list, shuffle it again and reset the index
            if (currentQuoteIndex >= allQuotes.size()) {
                Collections.shuffle(allQuotes);
                currentQuoteIndex = 0;
            }
        } else {
            // Display a message if no quotes are available
            quoteTextView.setText("No quotes available.");
            authorTextView.setText("");
        }
    }

    /**
     * This method creates an Intent to share the current quote.
     */
    private void shareQuote() {
        String currentQuote = quoteTextView.getText().toString();
        String currentAuthor = authorTextView.getText().toString();
        String shareText = currentQuote + " " + currentAuthor;

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

        startActivity(Intent.createChooser(shareIntent, "Share quote via"));
    }
}
